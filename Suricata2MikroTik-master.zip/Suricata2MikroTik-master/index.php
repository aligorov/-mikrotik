<?php
/*****************************
 *
  *
 * This file is the webgui for update and manager rules of project:
 *
 * https://github.com/elmaxid/Suricata2MikroTik *
 * 
 * Author: Maximiliano Dobladez info@mkesolutions.net
 *
 * http://maxid.com.ar | http://www.mkesolutions.net  
 *
 *
 * LICENSE: GPLv2 GNU GENERAL PUBLIC LICENSE
 *
 * 
 * v1.0 -   initial version
 ******************************/

 header("Location: www/");?>
